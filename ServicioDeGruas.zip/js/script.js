

function openInstagramAndRefresh() {
    // Abre Instagram en una nueva pestaña
    window.open('https://www.instagram.com/gruas.myc/', '_blank');

    // Recarga la página actual
    location.reload();
}



function openWhatsAppAndRefresh() {
    // Mensaje predefinido para la solicitud del servicio
    const message = "Hola, estoy interesado en solicitar el servicio de grúa. ¿Podrían brindarme más información?";

    // Abre WhatsApp con el mensaje predefinido en una nueva pestaña
    window.open(`https://wa.me/+56985607542?text=${encodeURIComponent(message)}`, '_blank');

    // Recarga la página actual
    location.reload();
}




function openFacebookAndRefresh() {
    // Abre Facebook en una nueva pestaña
    window.open('https://www.facebook.com/profile.php?id=61566129607635&mibextid=LQQJ4d', '_blank');

    // Recarga la página actual
    location.reload();
}









